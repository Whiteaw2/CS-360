package com.example.cs_360_x6157_projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.content.Intent;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.example.cs_360_x6157_projecttwo.database.AppDatabase;
import com.example.cs_360_x6157_projecttwo.database.entity.Product;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ArrayAdapter<String> adapter;
    private ListView productListView;
    private List<Product> products;
    private Product selectedProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        productListView = findViewById(R.id.productListView);


        productListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Debug", "Item clicked at position: " + position);
                Log.d("Debug", "Enter click event");
                if (products != null) {
                    selectedProduct = products.get(position);
                    Log.d("Debug", "Selected product: " + selectedProduct.getName());
                }
            }
        });

        Log.d("Debug", "LoadProductsTask AsyncTask execution started");
        new LoadProductsTask().execute();

        Button editButton = findViewById(R.id.editButton);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Debug", "Inside editButton click listener");
                if (selectedProduct != null) {
                    Log.d("Debug", "selectedProduct is not null");

                    Intent intent = new Intent(MainActivity.this, EditActivity.class);
                    intent.putExtra("selectedProductId", selectedProduct.getId()); // Assuming Product has a method getId()
                    startActivity(intent);
                } else {
                    Log.d("Debug", "selectedProduct is null");
                    Toast.makeText(MainActivity.this, "Select a product to edit", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button outgoing = findViewById(R.id.outgoing);
        outgoing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), incomingOutgoingActivity.class);
                startActivity(intent);
            }
        });

        Button incoming = findViewById(R.id.incoming);
        incoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), incomingOutgoingActivity.class);
                startActivity(intent);
            }
        });

        ImageButton settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), settingsActivity.class);
                startActivity(intent);
            }
        });
    }

    private class LoadProductsTask extends AsyncTask<Void, Void, List<Product>> {

        @Override
        protected void onPreExecute() {
            Log.d("Debug", "LoadProductsTask onPreExecute");
            super.onPreExecute();
        }

        @Override
        protected List<Product> doInBackground(Void... voids) {
            Log.d("Debug", "LoadProductsTask doInBackground started");
            List<Product> products = AppDatabase.getDatabase(getApplicationContext()).productDao().getAllProducts();
            Log.d("Debug", "LoadProductsTask doInBackground completed");
            return products;
        }

        @Override
        protected void onPostExecute(List<Product> productsResult) {
            products = productsResult;
            Log.d("Debug", "Number of products received: " + products.size());
            Log.d("Debug", "onPostExecute started");
            String[] productNames = new String[products.size()];
            for (int i = 0; i < products.size(); i++) {
                productNames[i] = products.get(i).getName();
                Log.d("Debug", "product names " + Arrays.toString(productNames));
            }
            Log.d("DatabaseData", Arrays.toString(productNames));

            adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, productNames);
            productListView.setAdapter(adapter);
        }
    }
}


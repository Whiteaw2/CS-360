package com.example.cs_360_x6157_projecttwo.database;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.cs_360_x6157_projecttwo.database.dao.ProductDao;
import com.example.cs_360_x6157_projecttwo.database.dao.UserDao;
import com.example.cs_360_x6157_projecttwo.database.entity.Product;
import com.example.cs_360_x6157_projecttwo.database.entity.User;

@Database(entities = {Product.class, User.class}, version = 3, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract ProductDao productDao();
    public abstract UserDao userDao();

    private static volatile AppDatabase INSTANCE;

    private static final RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsync(INSTANCE).execute();
            Log.d("Debug", "Database callback onCreate");
        }

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            Log.d("Debug", "Database callback onOpen");
        }
    };

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "app_database")
                            .addCallback(sRoomDatabaseCallback)
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {
        private final ProductDao mProductDao;
        private final UserDao mUserDao;

        PopulateDbAsync(AppDatabase db) {
            mProductDao = db.productDao();
            mUserDao = db.userDao();
        }

        @Override
        protected Void doInBackground(final Void... params) {
            Log.d("Debug", "PopulateDbAsync doInBackground started");

            // Insert products
            long id1 = mProductDao.insertProduct(new Product("FAKESKU1", "Product1", "This is a description for Product 1", 30));
            long id2 = mProductDao.insertProduct(new Product("FAKESKU2", "Product2", "This is a description for Product 2", 40));
            Log.d("Debug", "Inserted products with IDs: " + id1 + ", " + id2);

            // Insert default user
            long userId = mUserDao.insertUser(new User("test", "test"));
            Log.d("Debug", "Inserted default user with ID: " + userId);

            Log.d("Debug", "PopulateDbAsync doInBackground completed");
            return null;
        }
    }
}

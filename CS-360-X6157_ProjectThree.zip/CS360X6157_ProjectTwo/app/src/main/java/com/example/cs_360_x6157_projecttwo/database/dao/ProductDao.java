package com.example.cs_360_x6157_projecttwo.database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.cs_360_x6157_projecttwo.database.entity.Product;

import java.util.List;

@Dao
public interface ProductDao {

    @Query("SELECT * FROM products")
    List<Product> getAllProducts();

    @Query("SELECT * FROM products WHERE id = :productId")
    Product getProductById(int productId);

    @Insert
    long insertProduct(Product product);

    @Update
    int updateProduct(Product product);

    @Delete
    int deleteProduct(Product product);
}

package com.example.cs_360_x6157_projecttwo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs_360_x6157_projecttwo.database.AppDatabase;
import com.example.cs_360_x6157_projecttwo.database.entity.Product;

public class EditActivity extends AppCompatActivity {

    private Product selectedProduct;
    private EditText titleEditText, skuEditText, descriptionEditText, quantityEditText;
    private ImageView itemPhotoImageView;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        // Initialize UI elements
        titleEditText = findViewById(R.id.title);
        skuEditText = findViewById(R.id.sku);
        descriptionEditText = findViewById(R.id.description);
        quantityEditText = findViewById(R.id.quantity);
        itemPhotoImageView = findViewById(R.id.itemPhoto);
        saveButton = findViewById(R.id.saveButton);

        int selectedProductId = getIntent().getIntExtra("selectedProductId", -1);
        if (selectedProductId == -1) {
            Toast.makeText(this, "Error: No product ID provided.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        new LoadProductTask().execute(selectedProductId);

        // Button to save the edited details
        saveButton.setOnClickListener(v -> {
            if (selectedProduct != null) {
                selectedProduct.setName(titleEditText.getText().toString());
                selectedProduct.setSKU(skuEditText.getText().toString());
                selectedProduct.setDescription(descriptionEditText.getText().toString());
                selectedProduct.setQuantity(Integer.parseInt(quantityEditText.getText().toString()));
                // TODO: Handle image saving if required

                new UpdateProductTask().execute(selectedProduct);
            } else {
                Toast.makeText(this, "Error: Please ensure product is loaded before saving.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class LoadProductTask extends AsyncTask<Integer, Void, Product> {

        @Override
        protected Product doInBackground(Integer... integers) {
            return AppDatabase.getDatabase(getApplicationContext()).productDao().getProductById(integers[0]);
        }

        @Override
        protected void onPostExecute(Product product) {
            selectedProduct = product;
            if (selectedProduct != null) {
                titleEditText.setText(selectedProduct.getName());
                skuEditText.setText(selectedProduct.getSKU());
                descriptionEditText.setText(selectedProduct.getDescription());
                quantityEditText.setText(String.valueOf(selectedProduct.getQuantity()));

                // TODO: Populate itemPhotoImageView
            } else {
                Toast.makeText(EditActivity.this, "Error: Product not found.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }
    }

    private class UpdateProductTask extends AsyncTask<Product, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Product... products) {
            try {
                AppDatabase.getDatabase(getApplicationContext()).productDao().updateProduct(products[0]);
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(EditActivity.this, "Product updated successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EditActivity.this, "Error updating product. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

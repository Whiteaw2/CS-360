package com.example.cs_360_x6157_projecttwo.database.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.OnConflictStrategy;

import com.example.cs_360_x6157_projecttwo.database.entity.User;

@Dao
public interface UserDao {

    // Method to insert a new user
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insertUser(User user); // Returns the new row id, or -1 in case of an error

    // Method to get a user by their username
    @Query("SELECT * FROM users WHERE username = :username")
    User getUserByUsername(String username);

    // Method to authenticate a user
    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    User authenticate(String username, String password);
}
